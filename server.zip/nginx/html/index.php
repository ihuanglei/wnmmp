<?
    phpinfo();

?>
